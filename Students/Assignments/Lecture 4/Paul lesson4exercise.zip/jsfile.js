function changeContent() {
    document.getElementById("para1").innerHTML = "This is a new paragraph"
    document.getElementById("para2").innerHTML = "This is a brand new paragraph"
}

function changeImgSrc(){
    document.getElementById("image1").src = "best.jpg"
    document.getElementById("image2").src = "bigger.jpg"
}

function changeBackground(){
    document.getElementById("body").style.backgroundColor = "blue"
}

function hideElement(){
    document.getElementById("head1").style.display = "none"
    document.getElementById("head2").style.display = "none"
}

function showElement(){
    document.getElementById("head1").style.display = "block"
    document.getElementById("head2").style.display = "block"
}

document.getElementById("Change-Content").onclick = changeContent;
document.getElementById("Change-Content").onclick = changeContent;

document.getElementById("ChangesImage").onclick = changeImgSrc;
document.getElementById("ChangesImage").onclick = changeImgSrc;

document.getElementById("ChangesBackground").onclick = changeBackground;

document.getElementById("Hide_Heading").onclick = hideElement;
document.getElementById("HideHead").onclick = hideElement;

document.getElementById("Show_Heading").onclick = showElement;
document.getElementById("ShowHead").onclick = showElement;


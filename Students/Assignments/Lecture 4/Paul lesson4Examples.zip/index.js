
function changeContent(){
    document.getElementById("demo").innerHTML = "Yo!"
}

function changeImgSrc() {
    document.getElementById("img").src = "cool.jpg"
}

function changeBackground() {
    document.getElementById("body").style.backgroundColor = "blue"
}

function hideElement(){
    document.getElementById("demo").style.display = "none"
}

function showElement(){
    document.getElementById("demo").style.display = "block"
}

document.getElementById("change-content").onclick = changeContent;
document.getElementById("change-img").onclick = changeImgSrc;
document.getElementById("change-background").onclick = changeBackground;
document.getElementById("hide-element").onclick = hideElement;
document.getElementById("show-element").onclick = showElement;